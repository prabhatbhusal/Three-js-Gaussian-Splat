import { useEffect, useMemo, useRef, useState } from 'react';
import { Canvas, useThree } from '@react-three/fiber';
import { useRoomManager } from './lcc/useRoomManager.js';
import { useLccWalker } from './lcc/useLccWalker.js';
import { DebugHud } from './lcc/DebugHud.jsx';
import { ROOMS, validateGraph } from './lcc/doors.js';
import './hud.css';

/* ------------------------------------------------------------------ */
/* Inside the Canvas                                                  */
/* ------------------------------------------------------------------ */

function Tour({ onState }) {
  const manager = useRoomManager({ dev: import.meta.env.DEV });
  const walker = useLccWalker({
    renderer: manager.activeRenderer,
    roomId: manager.active,
    enabled: !manager.transitioning
  });

  // Publish state out to the DOM overlays. Context does not usefully cross the
  // Canvas boundary, so lift instead of trying to consume it from outside.
  const walkerRef = useRef(walker);
  walkerRef.current = walker;

  useEffect(() => {
    onState({
      active: manager.active,
      activeName: manager.activeName,
      transitioning: manager.transitioning,
      progress: manager.progress,
      neighbours: manager.neighbours,
      resident: manager.resident,
      tier: manager.tier,
      budget: manager.budget,
      stats: manager.stats,
      manager,
      go: (roomId) => {
        const from = manager.active;
        const res = manager.enterRoom(roomId, { from });
        walkerRef.current.reset([0, 2, 0], res?.yaw ?? 0);
      }
    });
  }, [
    manager.active, manager.transitioning, manager.progress,
    manager.resident, onState
    // eslint-disable-next-line react-hooks/exhaustive-deps
  ]);

  return null;
}

/* ------------------------------------------------------------------ */
/* DOM overlays                                                       */
/* ------------------------------------------------------------------ */

function Gate({ state }) {
  if (!state || !state.transitioning) return null;
  return (
    <div className="lcc-gate">
      <div>
        <p className="pct">{(state.progress * 100).toFixed(0)}%</p>
        <p className="msg">{state.activeName || 'Loading'}</p>
      </div>
    </div>
  );
}

/**
 * Door navigation. Temporary UI: eventually these are physical doors you walk
 * into, triggered by a proximity check against authored door positions. Buttons
 * first, because you cannot place door triggers until you have walked the rooms.
 */
function Doors({ state }) {
  if (!state || state.transitioning) return null;
  return (
    <div className="lcc-doors">
      <div className="lbl">Doors from {state.activeName}</div>
      {state.neighbours.map((id) => {
        const warm = state.resident.includes(id);
        return (
          <button key={id} onClick={() => state.go(id)} className={warm ? 'warm' : ''}>
            {ROOMS[id].name}
            <span className="tag">{warm ? 'ready' : 'load'}</span>
          </button>
        );
      })}
    </div>
  );
}

function Keys() {
  return (
    <div className="lcc-keys">
      <b>WASD</b> move · <b>Space</b> jump · <b>Shift</b> run<br />
      <b>P</b> record spawn point · <b>Shift+P</b> dump all · <b>F3</b> stats
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Root                                                              */
/* ------------------------------------------------------------------ */

export default function App() {
  const [state, setState] = useState(null);

  // Catch graph typos before they become a black screen.
  useEffect(() => {
    if (!import.meta.env.DEV) return;
    const problems = validateGraph();
    if (problems.length) {
      console.warn('[graph] ' + problems.length + ' issue(s):');
      problems.forEach((p) => console.warn('  · ' + p));
    } else {
      console.log('[graph] 17 rooms, 17 doors, all reachable');
    }
  }, []);

  const onState = useMemo(() => (s) => setState(s), []);

  return (
    <div className="lcc-root">
      <Canvas
        frameloop="always"
        gl={{ antialias: false }}
        dpr={[1, 2]}
        // far is overwritten per room by tuneCameraForRoom — this is only the
        // value for the first frame before any room loads.
        camera={{ fov: 60, near: 0.1, far: 250, position: [0, 2, 0] }}
      >
        <Tour onState={onState} />
      </Canvas>

      <Gate state={state} />
      <Doors state={state} />
      <Keys />
      {state?.transitioning === false && <div className="lcc-crosshair" />}
      {state && <DebugHud stats={state.stats} roomManager={state.manager} />}
    </div>
  );
}
